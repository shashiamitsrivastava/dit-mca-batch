public class EvenOddPosSum {
    public static void main(String[] args) {
        int num = 8765;
        int pos = 0;
        int evenSum = 0;
        int oddSum = 0;
        while(num!=0){
            int digit = num % 10;
            pos++;
            if(pos%2==0){
                evenSum+=digit;
            }
            else{
                oddSum+=digit;
            }
            // make number small
            num/=10; // num = num/10
        }
        System.out.println("Even Sum "+evenSum);
        System.out.println("Odd Sum "+oddSum);

    }
}
