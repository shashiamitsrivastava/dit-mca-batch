public class SwitchCase {

    static int getPrice(){
        int item = 1;
        switch(item){
            case 1:
                return 200;
                case 2:
                return 100;
                default:
                return 30;
        }
    }
    public static void main(String[] args) {
        // Java 14
        String item = "burger";
       int result =  switch(item){
            case "burger","pizza"-> 100;
            case "pepsi"->50;
            default ->  0;
        };
        System.out.println(result);
        switch(item){
            case "burger"->{
                System.out.println("hgdkjf");
                System.out.println("gfjglkd");
            }
            case "pepsi"->{
                System.out.println("hgdkjf");
                System.out.println("gfjglkd");
            }

        }
        // Java 7 
        // String item = "burger";
        // switch(item){
        //     case "burger":
        //     System.out.println("Price is 100Rs ");
                System.out.println(); // Statements (Block)
        //     break;
        //     case "pepsi":
        //     System.out.println("Price is 50Rs ");
        //     break;
        //     default:
        //     System.out.println("50 % off");
        // }
        /*int item = 1;
        final int BURGER_ITEM = 1;
        final int PEPSI_ITEM  = 2;
        switch(item){
            case BURGER_ITEM:
            System.out.println("Burger");
            break;
           
            case PEPSI_ITEM:
            System.out.println("Pepsi");
            break;
            default:
            System.out.println("Today Discount is 50% Off");
        }
        */
    }
}
