class SyntaxDemo{
    public static void main(String[] args) {
        // if else
        // simple if else
        if(true){

        }
        else{

        }
        // multiple if else
        // if(){

        // }
        // else if(){

        // }
        // nested if else
        // if(){
        //     if(){

        //     }
        //     else{

        //     }
        // }
        // else{

        // }
    }
}